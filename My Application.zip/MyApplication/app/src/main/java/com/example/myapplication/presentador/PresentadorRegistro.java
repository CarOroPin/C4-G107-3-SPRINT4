package com.example.myapplication.presentador;

import android.content.Context;
import android.content.Intent;
import android.media.SoundPool;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.myapplication.vista.VistaPrincipal;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class PresentadorRegistro {
    private Context context;
    private FirebaseAuth firebaseAuth;

    public PresentadorRegistro(Context context, FirebaseAuth firebaseAuth) {
        this.context = context;
        this.firebaseAuth = firebaseAuth;
    }

    public void registrar(String valor_correo, String valor_clave) {

        getFirebaseAuth().createUserWithEmailAndPassword(valor_correo, valor_clave).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Intent intent_principal;

                    Toast.makeText(getContext(), "Registro Exitoso", Toast.LENGTH_SHORT).show();
                    intent_principal =new Intent(getContext(), VistaPrincipal.class);
                    getContext().startActivity(intent_principal);
                }else{
                    Toast.makeText(getContext(),task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });

        }















    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public FirebaseAuth getFirebaseAuth() {
        return firebaseAuth;
    }

    public void setFirebaseAuth(FirebaseAuth firebaseAuth) {
        this.firebaseAuth = firebaseAuth;
    }
}
