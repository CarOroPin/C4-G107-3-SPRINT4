package com.example.myapplication.vista;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.modelo.Producto;

import java.util.ArrayList;



public class AdaptadorProducto extends RecyclerView.Adapter < AdaptadorProducto.ViewHolderProducto>  {
    ArrayList<Producto> listaProductos;
    Context context;

    private  OnProductoListener onProductoListener;


    public AdaptadorProducto(ArrayList<Producto> listaProductos, OnProductoListener onProductoListener) {
        this.listaProductos = listaProductos;
        this.onProductoListener = onProductoListener;
    }


    @NonNull
    @Override
    public ViewHolderProducto onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.item_producto,null,false);
        return new ViewHolderProducto(view,onProductoListener);
    }

    @Override    public void onBindViewHolder(@NonNull ViewHolderProducto holder, int position) {

        holder.getTextview_nombre().setText(listaProductos.get(position).getNombreProducto());
        holder.getTextview_porcion().setText(listaProductos.get(position).getPorcionProducto());
        holder.getTextView_sabor().setText(listaProductos.get(position).getSaborProducto());

        Glide.with(context)
                .load(listaProductos.get(position).getFotoProducto())
                .into(holder.getImageview_foto());

    }

    @Override
    public int getItemCount() {
        return listaProductos.size();
    }



    public class ViewHolderProducto extends RecyclerView.ViewHolder  implements View.OnClickListener {
        private TextView textview_nombre,textview_porcion, textView_sabor;
        private ImageView imageview_foto;

        OnProductoListener onProductoListener;

        public ViewHolderProducto(@NonNull View itemView,OnProductoListener onProductoListener) {
            super(itemView);
            textview_nombre = itemView.findViewById(R.id.id_ip_textview_nombre);
            textview_porcion = itemView.findViewById(R.id.id_ip_textview_porcion);
            textView_sabor = itemView.findViewById(R.id.id_ip_textview_sabor);
            imageview_foto = itemView.findViewById(R.id.id_ip_imagenview_producto);

            this.onProductoListener= onProductoListener;
            itemView.setOnClickListener(this);
        }

        public TextView getTextview_nombre() {
            return textview_nombre;
        }

        public void setTextview_nombre(TextView textview_nombre) {
            this.textview_nombre = textview_nombre;
        }

        public TextView getTextview_porcion() {
            return textview_porcion;
        }

        public void setTextview_porcion(TextView textview_porcion) {
            this.textview_porcion = textview_porcion;
        }

        public TextView getTextView_sabor() {
            return textView_sabor;
        }

        public void setTextView_sabor(TextView textView_sabor) {
            this.textView_sabor = textView_sabor;
        }

        public ImageView getImageview_foto() {
            return imageview_foto;
        }

        public void setImageview_foto(ImageView imageview_foto) {
            this.imageview_foto = imageview_foto;
        }

        @Override
        public void onClick(View view) {
            onProductoListener.onProductoClick(getAdapterPosition());
        }
    }


    public interface OnProductoListener{
        void onProductoClick(int position);
    }


}
