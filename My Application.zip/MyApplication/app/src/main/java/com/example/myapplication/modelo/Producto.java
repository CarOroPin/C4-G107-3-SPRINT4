package com.example.myapplication.modelo;

public class Producto {
    private String identificadorProducto;
    private String nombreProducto;
    private String porcionProducto;
    private String saborProducto;
    private String fotoProducto;

    public Producto() {

    }

    public Producto(String identificadorProducto, String nombreProducto, String porcionProducto, String saborProducto, String fotoProducto) {
        this.identificadorProducto = identificadorProducto;
        this.nombreProducto = nombreProducto;
        this.porcionProducto = porcionProducto;
        this.saborProducto = saborProducto;
        this.fotoProducto = fotoProducto;
    }

    public String getIdentificadorProducto() {
        return identificadorProducto;
    }

    public void setIdentificadorProducto(String identificadorProducto) {
        this.identificadorProducto = identificadorProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getPorcionProducto() {
        return porcionProducto;
    }

    public void setPorcionProducto(String porcionProducto) {
        this.porcionProducto = porcionProducto;
    }

    public String getSaborProducto() {
        return saborProducto;
    }

    public void setSaborProducto(String saborProducto) {
        this.saborProducto = saborProducto;
    }

    public String getFotoProducto() {
        return fotoProducto;
    }

    public void setFotoProducto(String fotoProducto) {
        this.fotoProducto = fotoProducto;
    }
}
