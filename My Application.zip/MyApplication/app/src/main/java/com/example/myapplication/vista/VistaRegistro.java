package com.example.myapplication.vista;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.myapplication.R;
import com.example.myapplication.presentador.PresentadorRegistro;
import com.google.firebase.auth.FirebaseAuth;


public class VistaRegistro extends AppCompatActivity implements View.OnClickListener {
    EditText editText_correo, editText_clave;
    ImageButton imageButton_registrar;

    FirebaseAuth firebaseAuth;
    PresentadorRegistro presentadorRegistro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vista_registro);

        editText_correo = findViewById(R.id.id_vr_edittext_correo);
        editText_clave = findViewById(R.id.id_vr_edittext_clave);

        imageButton_registrar = findViewById(R.id.id_vr_imagebutton_registrar);
        imageButton_registrar.setOnClickListener(this);

        firebaseAuth = FirebaseAuth.getInstance();
        presentadorRegistro = new PresentadorRegistro(VistaRegistro.this, firebaseAuth);

    }

    @Override
    public void onClick(View view) {
        String valor_correo, valor_clave;

        switch (view.getId()){
            case R.id.id_vr_imagebutton_registrar:
                valor_correo = editText_correo.getText().toString().trim();
                valor_clave = editText_clave.getText().toString().trim();
                presentadorRegistro.registrar(valor_correo, valor_clave);
                break;
        }
    }
}