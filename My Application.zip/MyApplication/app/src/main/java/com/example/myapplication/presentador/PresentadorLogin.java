package com.example.myapplication.presentador;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.myapplication.vista.VistaPrincipal;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class PresentadorLogin {
    private Context context;
    private FirebaseAuth firebaseAuth;

    public PresentadorLogin(Context context, FirebaseAuth firebaseAuth) {
        this.context = context;
        this.firebaseAuth = firebaseAuth;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public FirebaseAuth getFirebaseAuth() {
        return firebaseAuth;
    }

    public void setFirebaseAuth(FirebaseAuth firebaseAuth) {
        this.firebaseAuth = firebaseAuth;
    }

    public void iniciarSesion(String valor_correo, String valor_clave) {
        ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Verificando inicio de sesion");
        progressDialog.setCancelable(false);
        progressDialog.show();

        getFirebaseAuth().signInWithEmailAndPassword(valor_correo, valor_clave).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                Intent intent_principal;

                if(task.isSuccessful()){

                    progressDialog.dismiss();
                    Toast.makeText(getContext(), "Usuario logueado con exito", Toast.LENGTH_SHORT).show();
                    intent_principal = new Intent(getContext(), VistaPrincipal.class);
                    getContext().startActivity(intent_principal);

                }else{
                    progressDialog.dismiss();
                    Toast.makeText(getContext(),task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
